package com.Final.HospitalManagementSystem.Controller;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Services.MedicineService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
public class MedicineController {
    private final MedicineService medicineService;
@Autowired
    public MedicineController(MedicineService medicineService) {
        this.medicineService = medicineService;
    }
@PostMapping("/medicine/new")
    public Medicine saveMedicine(@RequestBody Medicine medicine){
    return medicineService.saveMedicine(medicine);
    }
@GetMapping("/medicine/get")
    public List<Medicine> getMedicines(){
    return medicineService.getMedicines();
    }
@DeleteMapping("/medicine/delete/{id}")
    public void deleteMedicine(@PathVariable("id")  Long id){
    medicineService.deleteMedicine(id);
    }
    @GetMapping("/medicine/search/{id}")
    public Medicine searcMedicine(@PathVariable("id") Long id){
    return medicineService.searchMedicine(id);
    }

    @PutMapping("/medicine/update/{id}")
    public Medicine updateMedicine(@PathVariable("id") Long id , @RequestBody Medicine medicine){
    return medicineService.updateMedicine(id, medicine);
    }


}
