package com.Final.HospitalManagementSystem.Services;


import com.Final.HospitalManagementSystem.Model.Patient;

import java.util.List;

public interface PatientService {
    List<Patient> getAllPatients();
    Patient savePatient(Patient patient);
    void deletePatient(Long id);
    Patient searchPatient(Long id);
    Patient updatePatient(Long id, Patient patient);
}

