package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Doctor;

import java.util.List;

public interface DoctorService {
    List<Doctor> getAllDoctors();
    Doctor getDoctorById(Long id);
    Doctor saveDoctor(Doctor doctor);
    void deleteDoctor(Long id);
    Doctor searchDoctor(Long id);
    Doctor updateDoctor(Long id, Doctor doctor);
}

