package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Medicine;

import java.util.List;

public interface MedicineService {
    Medicine saveMedicine(Medicine medicine);
    List<Medicine> getMedicines();
    void deleteMedicine(Long id);
    Medicine searchMedicine(Long id);

    Medicine updateMedicine(Long id, Medicine medicine);
}
