package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Repository.MedicineRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class MedicineServiceImpl implements MedicineService {
    private MedicineRepository medicineRepository;
@Autowired
    public MedicineServiceImpl(MedicineRepository medicineRepository) {
        this.medicineRepository = medicineRepository;
    }

    @Override
    public Medicine saveMedicine(Medicine medicine) {
        return medicineRepository.save(medicine);
    }

    @Override
    public List<Medicine> getMedicines() {
        return medicineRepository.findAll();
    }

    @Override
    public void deleteMedicine(Long id) {
        medicineRepository.deleteById(id);
    }

    @Override
    public Medicine searchMedicine(Long id) {
        return medicineRepository.findById(id).orElse(null);
    }

    @Override
    public Medicine updateMedicine( Long id, Medicine medicine) {
        Medicine existingMedicine = medicineRepository.findById(id).orElse(null);
        if (existingMedicine != null) {

            existingMedicine.setCategory(medicine.getCategory());
            existingMedicine.setAgeGroup(medicine.getAgeGroup());
            existingMedicine.setPrescription(medicine.getPrescription());
            return medicineRepository.save(existingMedicine);
        } else return null;
    }

}
