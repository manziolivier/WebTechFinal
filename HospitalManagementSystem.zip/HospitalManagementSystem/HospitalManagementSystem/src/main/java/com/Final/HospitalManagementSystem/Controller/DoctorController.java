package com.Final.HospitalManagementSystem.Controller;

import com.Final.HospitalManagementSystem.Model.Doctor;
import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Services.DoctorService;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import org.springframework.beans.factory.annotation.Autowired;


import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/doctors")
public class DoctorController {

    private final DoctorService doctorService;

    @Autowired
    public DoctorController(DoctorService doctorService) {
        this.doctorService = doctorService;
    }

    @GetMapping("/all")
    public List<Doctor> getAllDoctors() {
        return doctorService.getAllDoctors();
    }



    @PostMapping("/doctor/new")
    public Doctor saveDoctor(@RequestBody Doctor doctor) {

        return doctorService.saveDoctor(doctor);
    }
    @DeleteMapping("/doctor/delete/{id}")
    public void deleteDoctor(@PathVariable("id")  Long id){
        doctorService.deleteDoctor(id);
    }
    @GetMapping("/doctor/search/{id}")
    public Doctor searchDoctor(@PathVariable("id") Long id){

        return doctorService.searchDoctor(id);
    }

    @PutMapping("/doctor/update/{id}")
    public Doctor updateDoctor(@PathVariable("id") Long id , @RequestBody Doctor doctor){
        return doctorService.updateDoctor(id, doctor);
    }


}
