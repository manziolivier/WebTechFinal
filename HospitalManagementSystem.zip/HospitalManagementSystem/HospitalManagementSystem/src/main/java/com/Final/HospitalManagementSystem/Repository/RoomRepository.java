package com.Final.HospitalManagementSystem.Repository;


import com.Final.HospitalManagementSystem.Model.Room;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RoomRepository extends JpaRepository<Room, Long> {
    void deleteById(Long id);
}
