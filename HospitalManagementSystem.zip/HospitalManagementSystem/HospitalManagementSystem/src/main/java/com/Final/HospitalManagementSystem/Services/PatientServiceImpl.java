package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Model.Patient;
import com.Final.HospitalManagementSystem.Repository.PatientRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class PatientServiceImpl implements PatientService{
    private PatientRepository patientRepository;
@Autowired
    public PatientServiceImpl(PatientRepository patientRepository) {
        this.patientRepository = patientRepository;
    }

    @Override
    public List<Patient> getAllPatients() {
        return patientRepository.findAll();
    }


    @Override
    public Patient savePatient(Patient patient) {
        return patientRepository.save(patient);

    }

    @Override
    public void deletePatient(Long id) {
    patientRepository.deleteById(id);
    }

    @Override
    public Patient searchPatient(Long id) {
        return patientRepository.findById(id).orElse(null);
    }

    @Override
    public Patient updatePatient(Long id, Patient patient) {
        Patient existingPatient = patientRepository.findById(id).orElse(null);
        if (existingPatient != null) {
            existingPatient.setName(patient.getName());
            existingPatient.setAddress(patient.getAddress());
            existingPatient.setSymptoms(patient.getSymptoms());
            existingPatient.setStatus(patient.getStatus());
            return patientRepository.save(existingPatient);
        } else return null;
    }
    }

