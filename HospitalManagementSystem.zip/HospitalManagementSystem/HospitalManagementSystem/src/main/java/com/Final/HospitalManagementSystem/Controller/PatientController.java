package com.Final.HospitalManagementSystem.Controller;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Model.Patient;
import com.Final.HospitalManagementSystem.Services.PatientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin("http://localhost:3000")
@RequestMapping("/patients")
public class PatientController {

    private final PatientService patientService;


    @Autowired
    public PatientController(PatientService patientService) {
        this.patientService = patientService;
    }

    @GetMapping("patient/views")
    public List<Patient> getAlPatients(){
        return patientService.getAllPatients();
    }


    @PostMapping("/patient/new")
    public Patient savePatient(@RequestBody Patient patient) {

        return patientService.savePatient(patient);
    }

    @DeleteMapping("/patients/delete/{id}")
    public void deletePatient(@PathVariable("id")  Long id){
        patientService.deletePatient(id);
    }
    @GetMapping("/patients/search/{id}")
    public Patient searchPatient(@PathVariable("id") Long id){
        return patientService.searchPatient(id);
    }

    @PutMapping("/patients/update/{id}")
    public Patient updatePatient(@PathVariable("id") Long id , @RequestBody Patient patient){
        return patientService.updatePatient(id, patient);
    }

}
