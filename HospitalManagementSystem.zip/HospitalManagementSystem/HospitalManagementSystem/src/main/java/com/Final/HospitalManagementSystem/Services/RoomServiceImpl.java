package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Model.Room;
import com.Final.HospitalManagementSystem.Repository.RoomRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
@Service
public class RoomServiceImpl implements RoomService{
    private RoomRepository roomRepository;
@Autowired
    public RoomServiceImpl(RoomRepository roomRepository) {
        this.roomRepository = roomRepository;
    }


    @Override
    public List<Room> getAllRooms() {
       return roomRepository.findAll();
    }


    @Override
    public Room saveRoom(Room room) {
        return roomRepository.save(room);

    }

    @Override
    public void deleteRoom(Long id) {
    roomRepository.deleteById(id);
    }

    @Override
    public Room searchRoom(Long id) {
    return roomRepository.findById(id).orElse(null);
    }

    @Override
    public Room updateRoom(Long id, Room room) {
        Room existingRoom = roomRepository.findById(id).orElse(null);
        if (existingRoom != null) {
            existingRoom.setFloor(room.getFloor());
            existingRoom.setNumber(room.getNumber());
            return roomRepository.save(existingRoom);
        } else return null;
    }
    }

