package com.Final.HospitalManagementSystem.Controller;

import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Model.Room;
import com.Final.HospitalManagementSystem.Services.RoomService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/rooms")
@CrossOrigin("http://localhost:3000")
public class RoomController {

    private final RoomService roomService;

    @Autowired
    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping("room/views")
    public List<Room> getAllRooms(){
        return roomService.getAllRooms();
    }


    @PostMapping("/room/new")
    public Room saveRoom(@RequestBody Room room) {

        return roomService.saveRoom(room);
    }
    @DeleteMapping("/room/delete/{id}")
    public void deleteRoom(@PathVariable("id")  Long id){ roomService.deleteRoom(id);
    }
    @GetMapping("/room/search/{id}")
    public Room searchRoom(@PathVariable("id") Long id){
        return roomService.searchRoom(id);
    }

    @PutMapping("/room/update/{id}")
    public Room updateRoom(@PathVariable("id") Long id , @RequestBody Room room){
        return roomService.updateRoom(id, room);
    }

}

