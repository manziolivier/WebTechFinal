package com.Final.HospitalManagementSystem.Services;

import com.Final.HospitalManagementSystem.Model.Room;

import java.util.List;

public interface RoomService {
    List<Room> getAllRooms();

    Room saveRoom(Room room);
    void deleteRoom(Long id);
    Room searchRoom(Long id);
    Room updateRoom(Long id, Room room);

}

