package com.Final.HospitalManagementSystem.Services;


import com.Final.HospitalManagementSystem.Model.Doctor;
import com.Final.HospitalManagementSystem.Model.Medicine;
import com.Final.HospitalManagementSystem.Repository.DoctorRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DoctorServiceImpl implements DoctorService{
    private final DoctorRepository doctorRepository;
    //private final DoctorController doctorController;
    //private DoctorService doctorService;

@Autowired
    public DoctorServiceImpl(DoctorRepository doctorRepository) {
        this.doctorRepository = doctorRepository;
        //this.doctorController = doctorController;
        //this.doctorService = doctorService;
    }

    @Override
    public List<Doctor> getAllDoctors() {
        return doctorRepository.findAll();
    }

    @Override
    public Doctor getDoctorById(Long id) {
        return null;
    }

    @Override
    public Doctor saveDoctor(Doctor doctor) {
    return doctorRepository.save(doctor);
    }

    @Override
    public void deleteDoctor(Long id) {
    doctorRepository.deleteById(id);
    }

    @Override
    public Doctor searchDoctor(Long id) {
        return doctorRepository.findById(id).orElse(null);
    }

    @Override
    public Doctor updateDoctor(Long id, Doctor doctor) {
        Doctor existingDoctor = doctorRepository.findById(id).orElse(null);
        if (existingDoctor != null) {
            existingDoctor.setName(doctor.getName());
            existingDoctor.setAddress(doctor.getAddress());
            existingDoctor.setSpecialisation(doctor.getSpecialisation());
            existingDoctor.setNumber(doctor.getNumber());
            return doctorRepository.save(existingDoctor);
        } else return null;
    }
    }

